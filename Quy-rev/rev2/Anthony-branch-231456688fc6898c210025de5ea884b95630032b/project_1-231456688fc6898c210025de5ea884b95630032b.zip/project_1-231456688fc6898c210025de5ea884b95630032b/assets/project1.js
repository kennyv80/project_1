$(document).ready(function(){ 
    
var queryURL = "https://api.seatgeek.com/2/events?client_id=" + XXX + "MTc0MzY2MTB8MTU2MzAzNTMyMC45Ng";

$.ajax({
    url: queryURL,
    method: "GET"
  }).then(function(response) {


  };
  
};  